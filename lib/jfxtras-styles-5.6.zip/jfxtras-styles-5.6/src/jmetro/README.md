## Sources have changed place
The project sources have changed place.  
- You'll find themes that are only comprised of stylesheets under "stylesheets" project ("stylesheets" directory).  
- JMetro is under "jmetro" ("jmetro" directory)  
- Code samples, that show how to work with a theme and how controls look with that theme are under "samples" ("samples" directory)   

# JMetro
A set of stylesheets (and new skins) based on the Metro design style. These controls and stylesheet are to be used in JavaFX application.

## Documentation
Documentation on JMetro can be found in this link: [JMetro Java, Javafx theme documentation](https://pixelduke.com/java-javafx-theme-jmetro).