# Stylesheets

This is a collection of themes that are just composed of stylesheets, in other words, themes with just CSS files without 
new Skins or Controls.